import csv

def read_worldcupdata():
    while True:
        user_input = input('Enter "worldcups.csv" CSV file: ')
        try:
            worldcupsdata = []
            with open(user_input) as data_file:
                for data in csv.DictReader(data_file):
                    worldcupsdata.append(data)
            break
        except FileNotFoundError:
            print(f"Filename {user_input} does not exist. Please enter again.")
    return worldcupsdata


def option1(worldcupsdata):
    all_year = {data["year"]: data["winner"] for data in worldcupsdata}
    while True:
        year = input("Input year (or [back]): ")
        if year == "back":
            break
        elif year not in all_year.keys():
            print(f"The key {year} does not exist.")
        else:
            print(f"The winner is {all_year[year]}.")


def option2(worldcupsdata):
    year_goal = {data["year"]: data["goals_scored"] for data in worldcupsdata}
    while True:
        user_year = input("Input number of goals (or [back]): ")
        if user_year == "back":
            break
        elif not user_year.isdigit():
            print("Please type number.")
        else:
            temp = {}
            for year, goal in year_goal.items():
                if int(goal) > int(user_year):
                    temp[year] = goal
            print(
                f"There are {len(temp)} world cups that has goals scored more than {user_year}.")
            for year, goal in temp.items():
                print(f"Year {year} has {goal} goals scored.")


def option3(worldcupsdata):
    while True:
        user_input = input('Enter "europe.csv" CSV file: ')
        try:
            europesdata = []
            with open(user_input) as data_file:
                for data in csv.DictReader(data_file):
                    europesdata.append(data)
            break
        except FileNotFoundError:
            print(f"Filename {user_input} does not exist. Please enter again.")
    europe_name = [europe["name"] for europe in europesdata]
    all_winner = {world["year"]: world["winner"] for world in worldcupsdata}
    for year, winner in all_winner.items():
        for europe in europe_name:
            if europe == winner:
                print(f"Year {year}, winner from europe is {winner}.")


worldcupdata = read_worldcupdata()
while True:
    print("Option 1: Winner")
    print("Option 2: Goal")
    print("Option 3: Europe")
    user_input = input("Choose the option (or [exit] to quit): ")
    if user_input == "exit":
        break
    elif user_input == "1":
        option1(worldcupdata)
    elif user_input == "2":
        option2(worldcupdata)
    elif user_input == "3":
        option3(worldcupdata)
    else:
        print("Please input correct option.")
        