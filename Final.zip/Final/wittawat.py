file_name = input("Enter score file: ")
with open(file_name) as file_data:
    data = [float(i) for i in file_data.read().splitlines() if i != ""]

average = sum(data)/len(data)
temp = []x
for i in data:
    temp.append((i-average)**2)
standard_deviation = (sum(temp)/(len(data)-1))**0.5
print(f"The average is {average:.2f}")
print(f"The SD is {standard_deviation:.2f}")
print("Scores below average are:")
for score in data:
    if score < average:
        print(score)
print("Scores above average are:")
for score in data:
    if score > average:
        print(score)