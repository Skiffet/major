class Generator:

    def __init__(self, product, ingredient, product_rate=1, ingredient_rate=1):
        if not isinstance(product, str):
            raise TypeError("Product must be string type")
        self.__product = product
        if not isinstance(ingredient, str):
            raise TypeError("Ingredient must be string type")
        self.__ingredient = ingredient
        if not isinstance(product_rate, (float, int)):
            raise TypeError("Product_rate must be float or integer type")
        self.__product_rate = product_rate
        if not isinstance(ingredient_rate, (float, int)):
            raise TypeError("Ingredient_rate must be float or integer type")
        self.__ingredient_rate = ingredient_rate
        self.__produced = 0

    def work(self, input_ingredient, input_amount):
        if input_ingredient != self.__ingredient:
            print("Wrong resource.")
        elif input_amount < 0:
            print("Negative resource count.")
        elif not isinstance(input_ingredient, str):
            raise TypeError("Ingredient_rate must be string type")
        elif not isinstance(input_amount, (float, int)):
            raise TypeError("Input_amount must be float or integer type")
        else:
            ingredient_amount = divmod(input_amount, self.__ingredient_rate)
            real_use_amount = ingredient_amount[0]*self.__ingredient_rate
            new_produce = self.__product_rate/self.__ingredient_rate*real_use_amount
            self.__produced += new_produce
            print(f"Produced {new_produce:g} {self.__product}.")


# product = input()
# ingredient = input()
# with_amounts = input()
# if with_amounts == "Y":
#     product_rate = int(input())
#     ingredient_rate = int(input())
#     g = Generator(product, ingredient, product_rate, ingredient_rate)
# else:
#     g = Generator(product, ingredient)
# n_orders = int(input())
# for i in range(n_orders):
#     input_ingredient = input()
#     input_amount = int(input())
#     g.work(input_ingredient, input_amount)
