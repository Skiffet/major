class VendingMachine:

    def __init__(self, price, capacity):
        if not isinstance(price, int):
            raise TypeError("Price must be integer type")
        self.__price = price
        if not isinstance(capacity, int):
            raise TypeError("Capacity must be integer type")
        self.__capacity = capacity
        self.__money = 0
        self.__drinks = 0
        self.__power = False

    @property
    def money(self):
        return self.__money

    @property
    def drinks(self):
        return self.__drinks

    @property
    def power(self):
        return self.__power

    @power.setter
    def power(self, set_power):
        if not isinstance(set_power, bool):
            raise TypeError("Power must be boolean type")
        self.__power = set_power

    def sell(self):
        if not self.__power:
            raise ValueError("There is no power")
        if self.__drinks == 0:
            raise ValueError("There is no drinks")
        self.__money += self.__price
        self.__drinks -= 1

    def refill(self, amount=None):
        if amount > self.__capacity:
            raise ValueError("Can't go above capacity")
        if self.__power:
            raise ValueError("Power is still one")
        if amount is None:
            self.__drinks = self.__capacity
        else:
            self.__drinks = amount

    def maintenance_mode(self):
        self.__money = 0
        self.__drinks = 0
        self.__power = False
