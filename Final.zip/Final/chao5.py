class Hero:
    def __init__(self, name, max_hp=100):
        self.__name = name
        self.__hp = self.__max_hp = max_hp
        self.__alive = True

    def __process_damage(self, damage):
        """ Update the damage value here before it gets subtracted from HP.
            For example, reduce it to apply defense, or divide it to apply
            damage resistance (50% damage, etc.). """
        return damage

    def attack(self, target):
        if self.__alive:
            target.take_hit(self.attack_value)

    def take_hit(self, damage):
        if self.__alive:
            self.__hp -= self.__process_damage(damage)
        if self.__hp <= 0:
            self.__hp = 0
            self.__alive = False

    @property
    def name(self):
        return self.__name

    @property
    def hp(self):
        return self.__hp

    @property
    def max_hp(self):
        return self.__max_hp

    def __str__(self):
        return f"{self.__name}: {self.__class__.__name__} {self.__hp}/{self.__max_hp}"


class Warrior(Hero):

    def __init__(self, name, max_hp=120, str=10):
        Hero.__init__(self, name, max_hp)
        self.__str = str
        self.__attack_value = self.__str*2

    @property
    def str(self):
        return self.__str

    @property
    def attack_value(self):
        return self.__attack_value

    def __process_damage(self, damage):
        return damage * 0.5


class Wizard(Hero):

    def __init__(self, name, max_hp=60, wis=5):
        Hero.__init__(self, name, max_hp)
        self.__wis = wis
        self.__attack_value = self.__wis*2

    @property
    def wis(self):
        return self.__wis

    @property
    def attack_value(self):
        return self.__attack_value

    def __process_damage(self, damage):
        return damage - 5
